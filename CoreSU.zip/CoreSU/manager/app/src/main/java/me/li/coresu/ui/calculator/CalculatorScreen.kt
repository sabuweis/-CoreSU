package me.li.coresu.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun CalculatorScreen() {
    var expression by rememberSaveable { mutableStateOf("") }
    var display by rememberSaveable { mutableStateOf("0") }
    var isResult by rememberSaveable { mutableStateOf(false) }
    var memory by rememberSaveable { mutableStateOf(0.0) }

    val bgColor = Color(0xFFFFFFFF)
    val textColor = Color(0xFF222222)
    val opBtnColor = Color(0xFFFFF0F0) 
    val opTextColor = Color(0xFFD84B4B)
    val numBtnColor = Color(0xFFF5F5F5)
    val numTextColor = Color(0xFF222222)
    val memBtnColor = Color(0xFFF5F5F5)
    val memTextColor = Color(0xFF888888)
    val eqBtnColor = Color(0xFFD84B4B)
    val eqTextColor = Color(0xFFFFFFFF)

    fun press(token: String) {
        if (isResult && token.all { it.isDigit() || it == '.' }) {
            expression = ""
            display = "0"
            isResult = false
        } else if (isResult) {
            expression = display
            isResult = false
        }

        when (token) {
            "AC" -> { expression = ""; display = "0"; isResult = false }
            "⌫" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                    display = if (expression.isEmpty()) "0" else expression
                }
            }
            "+/-" -> {
                if (expression.isNotEmpty() && expression != "0") {
                    expression = if (expression.startsWith("-")) expression.substring(1) else "-$expression"
                    display = expression
                }
            }
            "%" -> {
                if (expression.isNotEmpty()) {
                    try {
                        val v = expression.toDouble()
                        expression = (v / 100.0).toString()
                        display = expression
                    } catch (_: Exception) {}
                }
            }
            "mc" -> memory = 0.0
            "m+" -> try { memory += expression.toDouble() } catch (_: Exception) {}
            "m-" -> try { memory -= expression.toDouble() } catch (_: Exception) {}
            "mr" -> { expression += memory.toString(); display = expression }
            "=" -> {
                try {
                    val res = eval(expression)
                    display = res
                    isResult = true
                } catch (e: Exception) {
                    display = "错误"
                    isResult = true
                }
            }
            else -> {
                if (expression.length > 30) return 
                expression += token
                display = expression
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = bgColor) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 16.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("计算", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = textColor)
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.weight(1f))

            Box(
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Text(
                    text = display,
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Light,
                    color = textColor,
                    textAlign = TextAlign.End,
                    maxLines = 1
                )
            }

            val btnSize = 72.dp
            val spacing = 12.dp

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CalcBtn("mc", memBtnColor, memTextColor, btnSize) { press("mc") }
                CalcBtn("m+", memBtnColor, memTextColor, btnSize) { press("m+") }
                CalcBtn("m-", memBtnColor, memTextColor, btnSize) { press("m-") }
                CalcBtn("mr", memBtnColor, memTextColor, btnSize) { press("mr") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CalcBtn("AC", numBtnColor, opTextColor, btnSize) { press("AC") }
                CalcBtn("", numBtnColor, opTextColor, btnSize, isIcon = true) { press("⌫") }
                CalcBtn("+/-", numBtnColor, opTextColor, btnSize) { press("+/-") }
                CalcBtn("÷", opBtnColor, opTextColor, btnSize) { press("÷") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CalcBtn("7", numBtnColor, numTextColor, btnSize) { press("7") }
                CalcBtn("8", numBtnColor, numTextColor, btnSize) { press("8") }
                CalcBtn("9", numBtnColor, numTextColor, btnSize) { press("9") }
                CalcBtn("×", opBtnColor, opTextColor, btnSize) { press("×") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CalcBtn("4", numBtnColor, numTextColor, btnSize) { press("4") }
                CalcBtn("5", numBtnColor, numTextColor, btnSize) { press("5") }
                CalcBtn("6", numBtnColor, numTextColor, btnSize) { press("6") }
                CalcBtn("-", opBtnColor, opTextColor, btnSize) { press("-") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CalcBtn("1", numBtnColor, numTextColor, btnSize) { press("1") }
                CalcBtn("2", numBtnColor, numTextColor, btnSize) { press("2") }
                CalcBtn("3", numBtnColor, numTextColor, btnSize) { press("3") }
                CalcBtn("+", opBtnColor, opTextColor, btnSize) { press("+") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CalcBtn("%", numBtnColor, numTextColor, btnSize) { press("%") }
                CalcBtn("0", numBtnColor, numTextColor, btnSize) { press("0") }
                CalcBtn(".", numBtnColor, numTextColor, btnSize) { press(".") }
                CalcBtn("=", eqBtnColor, eqTextColor, btnSize) { press("=") }
            }
        }
    }
}

@Composable
private fun CalcBtn(
    text: String,
    bgColor: Color,
    textColor: Color,
    size: androidx.compose.ui.unit.Dp,
    isIcon: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier.size(size).background(bgColor, CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (isIcon) {
            Icon(Icons.AutoMirrored.Rounded.Backspace, "删除", tint = textColor, modifier = Modifier.size(28.dp))
        } else {
            Text(text, fontSize = 26.sp, color = textColor, fontWeight = FontWeight.Medium)
        }
    }
}

private fun eval(exp: String): String {
    val e = exp.replace("×", "*").replace("÷", "/")
    var res = 0.0
    var current = ""
    var lastOp = '+'
    for (c in e) {
        if (c in "+-*/") {
            if (current.isNotEmpty()) {
                val v = current.toDouble()
                res = when (lastOp) {
                    '+' -> res + v; '-' -> res - v; '*' -> res * v; '/' -> if (v == 0.0) throw Exception() else res / v
                    else -> v
                }
                current = ""
            }
            lastOp = c
        } else { current += c }
    }
    if (current.isNotEmpty()) {
        val v = current.toDouble()
        res = when (lastOp) {
            '+' -> res + v; '-' -> res - v; '*' -> res * v; '/' -> if (v == 0.0) throw Exception() else res / v
            else -> v
        }
    }
    return if (res % 1.0 == 0.0) res.toInt().toString() else String.format(Locale.US, "%.4f", res).trimEnd('0').trimEnd('.')
}
