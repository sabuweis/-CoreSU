package me.li.coresu.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun CalculatorScreen() {
    var expression by rememberSaveable { mutableStateOf("") }
    var display by rememberSaveable { mutableStateOf("0") }
    var isResult by rememberSaveable { mutableStateOf(false) }
    var memory by rememberSaveable { mutableStateOf(0.0) }

    val bgColor = Color(0xFFFFFFFF)
    val textColor = Color(0xFF222222)
    val opBtnColor = Color(0xFFFFF0F0) 
    val opTextColor = Color(0xFFD84B4B)
    val numBtnColor = Color(0xFFF5F5F5)
    val numTextColor = Color(0xFF222222)
    val memBtnColor = Color(0xFFF5F5F5)
    val memTextColor = Color(0xFF888888)
    val eqBtnColor = Color(0xFFD84B4B)
    val eqTextColor = Color(0xFFFFFFFF)

    fun press(token: String) {
        if (isResult && token.all { it.isDigit() || it == '.' }) {
            expression = ""
            display = "0"
            isResult = false
        } else if (isResult) {
            expression = display
            isResult = false
        }

        when (token) {
            "AC" -> { expression = ""; display = "0"; isResult = false }
            "⌫" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                    display = if (expression.isEmpty()) "0" else expression
                }
            }
            "+/-" -> {
                if (expression.isNotEmpty() && expression != "0") {
                    expression = if (expression.startsWith("-")) expression.substring(1) else "-$expression"
                    display = expression
                }
            }
            "%" -> {
                if (expression.isNotEmpty()) {
                    try {
                        val v = expression.toDouble()
                        expression = (v / 100.0).toString()
                        display = expression
                    } catch (_: Exception) {}
                }
            }
            "mc" -> memory = 0.0
            "m+" -> try { memory += expression.toDouble() } catch (_: Exception) {}
            "m-" -> try { memory -= expression.toDouble() } catch (_: Exception) {}
            "mr" -> { expression += memory.toString(); display = expression }
            "=" -> {
                try {
                    val res = eval(expression)
                    display = res
                    isResult = true
                } catch (e: Exception) {
                    display = "错误"
                    isResult = true
                }
            }
            else -> {
                if (expression.length > 30) return 
                expression += token
                display = expression
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = bgColor) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 16.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("计算", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = textColor)
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.weight(1f))

            Box(
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Text(
                    text = display,
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Light,
                    color = textColor,
                    textAlign = TextAlign.End,
                    maxLines = 1
                )
            }

            val btnSize = 72.dp
            val spacing = 12.dp

            fun Btn(text: String, bg: Color, fg: Color, isIcon: Boolean = false, onClick: () -> Unit) {
                Box(
                    modifier = Modifier.size(btnSize).background(bg, CircleShape).clickable { onClick() },
                    contentAlignment = Alignment.Center
                ) {
                    if (isIcon) {
                        Icon(Icons.AutoMirrored.Rounded.Backspace, "删除", tint = fg, modifier = Modifier.size(28.dp))
                    } else {
                        Text(text, fontSize = 26.sp, color = fg, fontWeight = FontWeight.Medium)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Btn("mc", memBtnColor, memTextColor) { press("mc") }
                Btn("m+", memBtnColor, memTextColor) { press("m+") }
                Btn("m-", memBtnColor, memTextColor) { press("m-") }
                Btn("mr", memBtnColor, memTextColor) { press("mr") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Btn("AC", numBtnColor, opTextColor) { press("AC") }
                Btn("", numBtnColor, opTextColor, isIcon = true) { press("⌫") }
                Btn("+/-", numBtnColor, opTextColor) { press("+/-") }
                Btn("÷", opBtnColor, opTextColor) { press("÷") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Btn("7", numBtnColor, numTextColor) { press("7") }
                Btn("8", numBtnColor, numTextColor) { press("8") }
                Btn("9", numBtnColor, numTextColor) { press("9") }
                Btn("×", opBtnColor, opTextColor) { press("×") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Btn("4", numBtnColor, numTextColor) { press("4") }
                Btn("5", numBtnColor, numTextColor) { press("5") }
                Btn("6", numBtnColor, numTextColor) { press("6") }
                Btn("-", opBtnColor, opTextColor) { press("-") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Btn("1", numBtnColor, numTextColor) { press("1") }
                Btn("2", numBtnColor, numTextColor) { press("2") }
                Btn("3", numBtnColor, numTextColor) { press("3") }
                Btn("+", opBtnColor, opTextColor) { press("+") }
            }
            Spacer(modifier = Modifier.height(spacing))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Btn("%", numBtnColor, numTextColor) { press("%") }
                Btn("0", numBtnColor, numTextColor) { press("0") }
                Btn(".", numBtnColor, numTextColor) { press(".") }
                Btn("=", eqBtnColor, eqTextColor) { press("=") }
            }
        }
    }
}

private fun eval(exp: String): String {
    val e = exp.replace("×", "*").replace("÷", "/")
    var res = 0.0
    var current = ""
    var lastOp = '+'
    for (c in e) {
        if (c in "+-*/") {
            if (current.isNotEmpty()) {
                val v = current.toDouble()
                res = when (lastOp) {
                    '+' -> res + v; '-' -> res - v; '*' -> res * v; '/' -> if (v == 0.0) throw Exception() else res / v
                    else -> v
                }
                current = ""
            }
            lastOp = c
        } else { current += c }
    }
    if (current.isNotEmpty()) {
        val v = current.toDouble()
        res = when (lastOp) {
            '+' -> res + v; '-' -> res - v; '*' -> res * v; '/' -> if (v == 0.0) throw Exception() else res / v
            else -> v
        }
    }
    return if (res % 1.0 == 0.0) res.toInt().toString() else String.format(Locale.US, "%.4f", res).trimEnd('0').trimEnd('.')
}
